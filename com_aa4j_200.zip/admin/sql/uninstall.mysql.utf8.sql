-- $Id: uninstall.mysql.utf8.sql 11/05/2011 18.34

DROP TABLE IF EXISTS `#__userextras`;

